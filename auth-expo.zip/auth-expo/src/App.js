import React, { Component } from 'react';
import { View } from 'react-native';
import firebase from 'firebase';
import { Header } from './components/common';
import LogInForm from './components/LogInForm';

class App extends Component {
	componentWillMount() {
		firebase.intializeApp({
			apiKey: 'AIzaSyDNz7YCwJqsediQQmDwWgVBs2_byM0bUa8',
			authDomain: 'authentication-8ceee.firebaseapp.com',
			databaseURL: 'https://authentication-8ceee.firebaseio.com',
			projectId: 'authentication-8ceee',
			storageBucket: 'authentication-8ceee.appspot.com',
			messagingSenderId: '903291514073'
		});

	}

	render() {
		return (
			<View> 
				<Header headerText="Authentication" />
				<LogInForm />
			</View>
			);

	}

}

export default App;